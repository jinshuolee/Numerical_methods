#include<iostream>
#include <iomanip>
#include<math.h>
#include <GL/glut.h>
#include <vector> 
#include <fstream>
#include <glm/vec3.hpp> // glm::vec3
#include <glm/vec4.hpp> // glm::vec4
#include <glm/mat4x4.hpp> // glm::mat4
#include <stdlib.h>
#include <cstdlib>
#include <stdio.h>
using namespace glm;
using namespace std;

#define HEIGHT 200 //the height of the show window
#define WIDTH 200 //the WIDTH of the show window
#define PI 3.1415926
void statespace();
void init();
void display();

int i, j, k;
int finalPoint = 0;	//�e���l����
double output[100000] = { 0 };	//system output : y
int numFinal;	//output point number
const double TotalTime = 0.1;	//step response time
double h = 0.0001;	//step length

int finalPoint2 = 0;	//�e���l����

class Point {
public:
	double x;
	double y;
	double z;
public:
	double func(double ui, double dcPt);
	double inputFeedrate(double v, double ui2, double dcPt);
};

double Point::func(double ui, double dcPt) {		//Ui���N����
	double v = 10;		//feedrate
	double Ts = 5 * pow(10, -4);
	double uii = ui + v * Ts / dcPt;
	return uii;
}

double Point::inputFeedrate(double v, double ui2, double dcPt) {		//Ui���N�����i����feedrate
	double Ts = 5 * pow(10, -4);
	double uii = ui2 + v * Ts / dcPt;
	return uii;
}

Point cPt[50] = { 0 };
Point Line[100000] = { 0 };
Point Ys[100000] = { 0 };
Point path[100000] = { 0 };


int main(int argc, char* argv[])
{
	cPt[0].x = 0;
	cPt[0].y = 10;
	cPt[0].z = 0;

	cPt[1].x = 20;
	cPt[1].y = 10;
	cPt[1].z = 1;

	cPt[2].x = 40;
	cPt[2].y = 10;
	cPt[2].z = 0;

	cPt[3].x = 60;
	cPt[3].y = 10;
	cPt[3].z = 1;

	cPt[4].x = 80;
	cPt[4].y = 10;
	cPt[4].z = 0;

	cPt[5].x = 90;
	cPt[5].y = 10;
	cPt[5].z = 0;

	cPt[6].x = 90;
	cPt[6].y = 50;
	cPt[6].z = 0;

	cPt[7].x = 20;
	cPt[7].y = 50;
	cPt[7].z = 0;

	cPt[8].x = 20;
	cPt[8].y = 30;
	cPt[8].z = 0;

	cPt[9].x = 0;
	cPt[9].y = 30;
	cPt[9].z = 0;

	cPt[10].x = 0;
	cPt[10].y = 10;
	cPt[10].z = 0;

	int t = 0;	//���N����
	double r = 10;


	double v;
	cout << "��JV =\n";		//------------��Jfeedrate
	cin >> v;
	int t2 = 0;

	for (i = 0; i < 10; i++) {
		Point pt1, pt2, ptt, ptt2;
		double ui = 0;
		double dCdt;
		pt1 = cPt[i];
		pt2 = cPt[i + 1];

		if (cPt[i].z == 0) {
			dCdt = sqrt(pow((pt2.x - pt1.x), 2) + pow((pt2.y - pt1.y), 2));
		}
		else {
			dCdt = PI * r;
		}

		//----------------------------------��l���|
		while (ui <= 1) {
			if (cPt[i].z == 0) {
				Line[t].x = (1 - ui) * pt1.x + ui * pt2.x;
				Line[t].y = (1 - ui) * pt1.y + ui * pt2.y;
			}
			else {
				Line[t].x = (pt1.x + pt2.x) / 2 + r * cos((ui + 1) * PI);
				Line[t].y = (pt1.y + pt2.y) / 2 + r * sin((ui + 1) * PI);
			}
			ui = ptt.func(ui, dCdt);	//-------------------------���N�U��Ui

			//cout << "finalPoint=" << finalPoint << "  x=" << Line[t].x << "	y=" << Line[t].y << endl;
			finalPoint = t;
			t++;
		}
		//cout << "finalPoint= " << finalPoint << endl;
		ui = 0;

		//---------------------------------��ڸ��|
		double ui2 = 0;
		while (ui2 <= 1) {
			if (cPt[i].z == 0) {
				path[t2].x = (1 - ui2) * pt1.x + ui2 * pt2.x;
				path[t2].y = (1 - ui2) * pt1.y + ui2 * pt2.y;
			}
			else {
				path[t2].x = (pt1.x + pt2.x) / 2 + r * cos((ui2 + 1) * PI);
				path[t2].y = (pt1.y + pt2.y) / 2 + r * sin((ui2 + 1) * PI);
			}
			ui2 = ptt2.inputFeedrate(v, ui2, dCdt);	//-------------------------���a�U��Ui

			//cout << "finalPoint2=" << finalPoint2 << "  x=" << path[t2].x << "	y=" << path[t2].y << endl;
			finalPoint2 = t2;
			t2++;
		}
		//cout << "finalPoint2= " << finalPoint2 << endl;
		ui2 = 0;
	}

	statespace();	//------------------------------����t�Ϊ���X

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);
	glutInitWindowPosition(1000, 200);
	glutInitWindowSize(500, 500);
	glutCreateWindow("OpenGL 3D View");
	init();
	glutDisplayFunc(display);
	//glutTimerFunc(16, timer, 0);
	glutMainLoop();
	return 0;
}

void statespace() {
	//---------------------------------------X
	double a0 = 3.62 * pow(10, -5);
	double a = -0.01823 / a0;
	double b = -4.716 / a0;
	double c = -360.2 / a0;
	double d = 0.007711 / a0;
	double e = 3.568 / a0;
	double f = 360.2 / a0;
	double A[3][3] = { {a,b,c},{1,0,0},{0,1,0} };
	double B[3][1] = { 1,0,0 };
	double C[1][3] = { d,e,f };

	double u = 0;
	int num = 0;
	double xi[3][1] = { 0 };
	for (double t = 0; t < TotalTime; t = t + h) {
		double xii[3][1] = { 0 };
		double y = 0;
		for (i = 0; i < 3; i++) {
			xii[0][0] += A[0][i] * xi[i][0];
			xii[1][0] += A[1][i] * xi[i][0];
			xii[2][0] += A[2][i] * xi[i][0];
		}
		xii[0][0] = h * (xii[0][0] + u * B[0][0]) + xi[0][0];
		xii[1][0] = h * (xii[1][0]) + xi[1][0];
		xii[2][0] = h * (xii[2][0]) + xi[2][0];
		for (i = 0; i < 3; i++) {
			y += C[0][i] * xi[i][0];
		}
		//cout << y << endl;
		for (i = 0; i < 3; i++) {
			xi[i][0] = xii[i][0];
		}
		output[num] = y;
		//cout << "t=" << t << "   y=" << output << "\n";
		numFinal = num;
		num++;
		u = 1;
	}
	//cout << "Output point num=" << numFinal;	//�̫ᦸ��

	//---------------------------------��ڸ��|X
	num = 0;
	for (int g = 0; g < 3; g++)
		xi[g][0] = 0;
	for (double t = 0; t < finalPoint2; t++) {
		double xii[3][1] = { 0 };
		double y = 0;
		double u = path[num].x;
		for (i = 0; i < 3; i++) {
			xii[0][0] += A[0][i] * xi[i][0];
			xii[1][0] += A[1][i] * xi[i][0];
			xii[2][0] += A[2][i] * xi[i][0];
		}
		xii[0][0] = h * (xii[0][0] + u * B[0][0]) + xi[0][0];
		xii[1][0] = h * (xii[1][0]) + xi[1][0];
		xii[2][0] = h * (xii[2][0]) + xi[2][0];
		for (i = 0; i < 3; i++) {
			y += C[0][i] * xi[i][0];
		}
		//cout << y << endl;
		for (i = 0; i < 3; i++) {
			xi[i][0] = xii[i][0];
		}
		Ys[num].x = y;
		//cout << "t=" << t << "   y=" << Ys[num].x << "\n";
		//numFinal = num;
		num++;
	}
	//cout << "num=" << num << endl;


	//------------------------------------Y
	double a0y = 3.817 * pow(10, -5);
	double ay = -0.01914 / a0y;
	double by = -4.944 / a0y;
	double cy = -375.9 / a0y;
	double dy = 0.008123 / a0y;
	double ey = 3.744 / a0y;
	double fy = 375.9 / a0y;
	double Ay[3][3] = { {ay,by,cy},{1,0,0},{0,1,0} };
	double By[3][1] = { 1,0,0 };
	double Cy[1][3] = { dy,ey,fy };
	//---------------------------------��ڸ��|Y
	num = 0;
	xi[0][0] = 10/dy;
	xi[1][0] = 0;
	xi[2][0] = 0;
	double x0[3][1] = { 10/dy,0,0 };
	for (double t = 0; t < finalPoint2; t++) {
		double xii[3][1] = { 0 };
		double y = 0;
		double u = path[num].y;
		for (i = 0; i < 3; i++) {
			xii[0][0] += Ay[0][i] * xi[i][0];
			xii[1][0] += Ay[1][i] * xi[i][0];
			xii[2][0] += Ay[2][i] * xi[i][0];
		}
		xii[0][0] = h * (xii[0][0] + u * By[0][0]) + xi[0][0];
		xii[1][0] = h * (xii[1][0]) + xi[1][0];
		xii[2][0] = h * (xii[2][0]) + xi[2][0];
		if (t < 100) {
			for (i = 0; i < 3; i++) {
				y += Cy[0][i] * x0[i][0];
			}
		}
		else {
			for (i = 0; i < 3; i++) {
				y += Cy[0][i] * xi[i][0];
			}
		}
		
		//cout << y << endl;
		for (i = 0; i < 3; i++) {
			xi[i][0] = xii[i][0];
		}
		Ys[num].y = y;
		//cout << "t=" << t << "   y=" << Ys[num].y  << "\n";
		//numFinal = num;
		num++;
		//cout << "u=" << u << "\n";
	}
	//cout << "num=" << num << endl;

	//-----------��X����
	//for (int dd = 0; dd < finalPoint2; dd++) {
	//	cout << "dd=" << dd << "  x= " << Ys[dd].x << "	y=" << Ys[dd].y << endl;
	//}
}

void init()
{
	glClearColor(1.0, 1.0, 1.0, 0.0);//the background color
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(-WIDTH / 2, WIDTH / 2, -HEIGHT / 2, HEIGHT / 2);
	glMatrixMode(GL_MODELVIEW);
}

void display() {
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();		//���m���e���w���x�}�����x�}

	//-------------------------------xy axis
	glLineWidth(1.0f);
	glBegin(GL_LINES);
	glColor3f(0.0, 0.0, 0.0);	//�¦�
	glVertex2d(-WIDTH / 2, 0);
	glVertex2d(WIDTH / 2, 0);
	glVertex2d(0, -HEIGHT / 2);
	glVertex2d(0, HEIGHT / 2);
	glEnd();

	//-----------------------------Car original path
	int t = 0;
	glLineWidth(2.0f);
	glColor3f(1.0, 0.0, 0.0);	//����
	glBegin(GL_LINES);
	while (t < finalPoint) {
		glVertex2d(Line[t].x, Line[t].y);
		glVertex2d(Line[t + 1].x, Line[t + 1].y);
		t++;
	}
	glEnd();

	//-----------------------------x,y different constant feedrate path
	glColor3f(0.0, 1.0, 0.0);	//���
	glBegin(GL_LINES);
	for (int i = 0; i < finalPoint2-1; i++) {
		glVertex2d(Ys[i].x, Ys[i].y);
		glVertex2d(Ys[i + 1].x, Ys[i + 1].y);
	}
	glVertex2d(Ys[finalPoint2-1].x, Ys[finalPoint2-1].y);
	glVertex2d(0,10);
	glEnd();

	//-----------------------------output response
	glColor3f(0.0, 0.0, 1.0);	//�Ŧ�
	glLineWidth(2.0f);
	glBegin(GL_LINES);
	i = 0;
	for (i = 0; i < numFinal; i++) {
		//�վ�y�Ыe
		//glVertex2d(i, output[i]);
		//glVertex2d((double)i+1, output[i+1]);

		////�վ�y�Ы�
		glVertex2d((double)i / 5 - 100, output[i] * 100 - 100);
		glVertex2d(((double)i + 1) / 5 - 100, output[i + 1] * 100 - 100);
	}
	glEnd();

	// �洫�e��w�s
	glutSwapBuffers();

	// Ĳ�o�e����s
	glutPostRedisplay();
}